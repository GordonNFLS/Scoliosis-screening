module.exports = { extends: ['@commitlint/config-conventional'] };
