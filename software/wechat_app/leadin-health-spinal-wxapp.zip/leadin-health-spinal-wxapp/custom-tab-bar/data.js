export default [{
    icon: 'home',
    text: '首页',
    url: 'pages/home/home',
  },
  // {
  //   icon: 'scanning',
  //   text: '扫一扫',
  //   url: '',
  // },
  {
    icon: 'person',
    text: '我的',
    url: 'pages/usercenter/index',
  },
];