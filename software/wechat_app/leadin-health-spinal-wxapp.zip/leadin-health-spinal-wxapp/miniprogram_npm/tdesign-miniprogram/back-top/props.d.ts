import { TdBackTopProps } from './type';
declare const props: TdBackTopProps;
export default props;
