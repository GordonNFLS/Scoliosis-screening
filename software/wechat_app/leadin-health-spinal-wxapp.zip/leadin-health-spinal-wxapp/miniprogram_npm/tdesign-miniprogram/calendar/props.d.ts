import { TdCalendarProps } from './type';
declare const props: TdCalendarProps;
export default props;
