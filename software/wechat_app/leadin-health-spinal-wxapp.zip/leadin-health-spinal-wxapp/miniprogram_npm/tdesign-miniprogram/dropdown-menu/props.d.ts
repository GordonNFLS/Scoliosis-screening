import { TdDropdownMenuProps } from './type';
declare const props: TdDropdownMenuProps;
export default props;
