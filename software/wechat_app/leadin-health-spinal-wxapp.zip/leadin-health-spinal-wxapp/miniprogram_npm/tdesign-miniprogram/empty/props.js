const props = {
    description: {
        type: String,
    },
    externalClasses: {
        type: Array,
    },
    icon: {
        type: null,
    },
    image: {
        type: String,
    },
};
export default props;
