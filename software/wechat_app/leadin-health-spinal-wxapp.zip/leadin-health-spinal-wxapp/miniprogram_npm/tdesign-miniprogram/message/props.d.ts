import { TdMessageProps } from './type';
declare const props: TdMessageProps;
export default props;
