import { TdResultProps } from './type';
declare const props: TdResultProps;
export default props;
