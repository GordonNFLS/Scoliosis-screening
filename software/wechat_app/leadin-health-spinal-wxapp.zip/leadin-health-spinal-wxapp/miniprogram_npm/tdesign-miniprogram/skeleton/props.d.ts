import { TdSkeletonProps } from './type';
declare const props: TdSkeletonProps;
export default props;
