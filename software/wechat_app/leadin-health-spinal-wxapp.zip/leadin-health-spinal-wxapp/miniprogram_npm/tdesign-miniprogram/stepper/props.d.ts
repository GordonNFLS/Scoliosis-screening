import { TdStepperProps } from './type';
declare const props: TdStepperProps;
export default props;
