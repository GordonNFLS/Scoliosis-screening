import { TdSwipeCellProps } from './type';
declare const props: TdSwipeCellProps;
export default props;
