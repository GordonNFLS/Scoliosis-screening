import { TdSwiperNavProps } from './type';
declare const props: TdSwiperNavProps;
export default props;
