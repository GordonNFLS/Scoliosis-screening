import { TdTabBarItemProps } from './type';
declare const props: TdTabBarItemProps;
export default props;
