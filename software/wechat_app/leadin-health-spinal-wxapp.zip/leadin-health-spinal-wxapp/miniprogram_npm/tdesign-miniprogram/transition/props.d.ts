import { TdTransitionProps } from './type';
declare const props: TdTransitionProps;
export default props;
