import { TdTreeSelectProps } from './type';
declare const props: TdTreeSelectProps;
export default props;
