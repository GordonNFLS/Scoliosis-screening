import {
  config,
  cdnBase
} from '../../config/index';
import {
  fetchSpineStudentListMeasure,
  fetchSpineMeasureAdd,
  fetchSpineStudentList
} from '../../services/api/api';
import dayjs from 'dayjs'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cdnBase,
    list: [],
    step: 0,
    currentStudent: null,
    nextStudent: null,
    keywords: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.init()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.init()
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  init() {
    wx.stopPullDownRefresh();
    this.setData({
      userType: config.userInfo.userType
    })
    fetchSpineStudentListMeasure({
      userId: config.userInfo.userId
    }).then(res => {
      const data = res.map(o => {
        return {
          ...o,
          birthday: dayjs(o.birthday * 1000).format('YYYY-MM-DD')
        }
      })
      const currentStep = wx.getStorageSync('currentStep')
      if (currentStep) {
        wx.removeStorageSync('currentStep')
        this.setData({
          step: currentStep
        })
      }
      let currentStudent = wx.getStorageSync('currentStudent')
      if (currentStudent) {
        wx.removeStorageSync('currentStudent')
        currentStudent = JSON.parse(currentStudent)
      } else {
        currentStudent = data[this.data.step]
      }
      const nextStudent = data[this.data.step + 1]
      this.setData({
        list: data,
        showList: data.slice(this.data.step + 1),
        currentStudent,
        nextStudent
      })
    })
  },
  search() {
    const {
      keywords,
      list,
      step
    } = this.data
    const index = list.findIndex(o => o.studentName == keywords)
    if (index == 0) {
      wx.showToast({
        title: `当前已是${keywords}`,
        icon: 'none'
      })
    } else if (index > 0) {
      const student = list.splice(index, 1)[0]
      list.splice(0, 0, student)
      this.setData({
        showList: list.slice(step + 1),
        currentStudent: student,
        nextStudent: list[step + 1] || null
      })
    } else {
      wx.showToast({
        title: `${keywords}不在名单内 `,
        icon: 'error'
      })
    }
  },
  goMeasure(e) {
    const {
      currentStudent,
      step
    } = this.data
    wx.setStorage({
      key: "currentStudent",
      data: JSON.stringify(currentStudent)
    })
    wx.setStorage({
      key: "currentStep",
      data: step
    })
    wx.navigateTo({
      url: '/pages/measure/index',
    })
  },
  next() {
    const {
      currentStudent,
      userType
    } = this.data;
    if (!currentStudent.measureThird) {
      wx.showToast({
        title: `当前${userType=='01'?'学生':'孩子'}未测量！`,
        icon: 'error'
      });
      return
    }
    const {
      measureFirst,
      measureSecond,
      measureThird,
      studentId
    } = currentStudent
    const _max = Math.max(measureFirst, measureSecond, measureThird)
    fetchSpineMeasureAdd({
      "bmiInfo": "",
      "measureInfo": _max <= 5 ? '正常' : _max <= 7 ? '低风险' : '高风险',
      "measureFirst": measureFirst,
      "measureSecond": measureSecond,
      "measureThird": measureThird,
      "studentId": studentId,
      "userId": config.userId,
    }).then(res => {
      if (res.code == 200) {
        const {
          step,
          list
        } = this.data
        this.setData({
          step: step + 1,
          showList: list.slice(step + 2),
          currentStudent: list[step + 1] || null,
          nextStudent: list[step + 2] || null
        })
      }
    })

  }
})