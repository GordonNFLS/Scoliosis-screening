import {
  config
} from '../../config/index';
import {
  wxLogin,
  fetchLoginByJsCode,
  fetchUserInfo
} from '../../services/api/api';
import dayjs from 'dayjs'
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.init()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  async init() {
    const {
      code
    } = await wxLogin()
    const res = await fetchLoginByJsCode({
      code
    })
    if (res.code == 200) {
      config.openId = res.data.openId
      config.unionId = res.data.unionId
      var isLogout = wx.getStorageSync('isLogout')
      if (!res.data.userId || (isLogout && isLogout == '1')) {
        wx.switchTab({
          url: `/pages/home/home`,
        });
        return
      }
      if (res.data.userId) {
        config.userId = res.data.userId
        this.initUser()
      }
    }
  },
  initUser() {
    fetchUserInfo({
      openId: config.openId,
      userId: config.userId
    }).then(res1 => {
      const data = res1
      config.userInfo = data
      if (config.userInfo.userName == null) {
        config.userInfo.userName = config.userInfo.nickName
      }
      if (config.userInfo.age > 0) {
        config.userInfo.ageStr = dayjs().diff(dayjs(config.userInfo.age * 1000), 'years')
      }
      wx.switchTab({
        url: `/pages/home/home`,
      });

    })
  }
})