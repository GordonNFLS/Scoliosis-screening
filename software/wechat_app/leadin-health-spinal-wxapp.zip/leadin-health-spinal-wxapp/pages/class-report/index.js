import dayjs from 'dayjs'
import {
  fetchSpineMeasureUserQuery
} from '../../services/api/api';
import {
  config,
  cdnBase
} from '../../config/index';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cdnBase,
    mode: '',
    dateVisible: false,
    date: new Date().getTime(),
    dateText: '',
    keywords: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.init()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  init() {
    this.setData({
      dateText: dayjs(this.data.date).format('YYYY-MM-DD')
    })
    this.search()

  },
  fetchData() {
    const {
      keywords,
      dateText,
      curtype
    } = this.data
    fetchSpineMeasureUserQuery({
      userId: config.userInfo.userId,
      studentName: keywords,
      time: parseInt(dayjs(dateText).valueOf() / 1000)
    }).then(res => {
      let list = res.data
      if (curtype == '1') {
        list = res.data.filter(o => o.measureInfo && o.measureInfo != '正常')
      } else if (curtype == '2') {
        list = res.data.filter(o => o.bmiInfo && o.bmiInfo != '正常')
      }
      this.setData({
        list: list
      })
    })
  },
  showPicker(e) {
    const {
      mode,
      value
    } = e.currentTarget.dataset;
    this.setData({
      mode,
      currentTime: value,
      date: dayjs(this.data[value]).valueOf(),
      [`${mode}Visible`]: true,
    });
  },
  hidePicker() {
    const {
      mode
    } = this.data;
    this.setData({
      [`${mode}Visible`]: false,
    });
  },
  onConfirm(e) {
    const {
      value
    } = e.detail;
    const {
      mode,
      currentTime
    } = this.data;

    this.setData({
      [mode]: value,
      [`${currentTime}`]: value,
    });
    this.search()
    this.hidePicker();
  },

  onColumnChange(e) {
    console.log('pick', e.detail.value);
  },
  search() {
    this.setData({
      curtype: null
    })
    this.fetchData()
  },
  filter(e) {
    const {
      type
    } = e.currentTarget.dataset
    const {
      curtype
    } = this.data
    if (curtype) {
      this.setData({
        curtype: null
      })
    } else {
      this.setData({
        curtype: type
      })
    }
    this.fetchData()
  },
  goHistory(e) {
    const {
      item
    } = e.currentTarget.dataset
    wx.setStorageSync('currentStudent', JSON.stringify(item))
    wx.navigateTo({
      url: '/pages/my/history/index',
    })
  }
})