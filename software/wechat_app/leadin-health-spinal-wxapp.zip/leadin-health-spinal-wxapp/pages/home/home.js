import {
  fetchMaterial
} from '../../services/api/api';
import {
  config,
  cdnBase
} from '../../config/index';
import dayjs from 'dayjs'
Page({
  data: {
    cdnBase,
    imgSrcs: [],
    menus: [{
        "label": '班级报表',
        "icon": '形状 1.png',
        "url": '/pages/class-report/index'
      },
      {
        "label": '体姿检测',
        "icon": '形状 3.png',
        "url": '/pages/body-measure/index'
      },
      {
        "label": '设备绑定',
        "icon": '形状 5.png',
        "url": '/pages/devbind/index'
      }
    ],
    menus1: [{
        "label": '历史数据',
        "icon": '形状 7(5).png',
        "url": '/pages/my/history/index'
      },
      {
        "label": '开始测量',
        "icon": '形状 8(1).png',
        "url": '/pages/body-measure/index'
      },
      {
        "label": '设备绑定',
        "icon": '形状 5.png',
        "url": '/pages/devbind/index'
      }
    ],
    pageLoading: false,
    current: 0,
    autoplay: true,
    duration: '500',
    interval: 5000,
    navigation: {
      type: 'dots'
    },
    swiperImageProps: {
      mode: 'scaleToFill'
    },
    marquee: {
      speed: 60,
      loop: -1,
      delay: 0,
    },
  },

  onShow() {
    this.getTabBar().init();
    this.init();
  },

  onLoad() {

    fetchMaterial({
      materialType: 0
    }).then(res => {
      this.setData({
        imgSrcs: res.map(o => o.imageUrl)
      })
      fetchMaterial({
        materialType: 1
      }).then(res => {
        this.setData({
          videos: res
        })
      })
    })

  },

  onReachBottom() {

  },

  onPullDownRefresh() {},

  init() {
    const hour = dayjs().hour()
    const welcome = hour >= 0 && hour <= 10 ? '早上好!' : hour > 10 && hour <= 14 ? '中午好!' : hour > 14 && hour <= 18 ? '下午好!' : '晚上好!';
    this.setData({
      welcome,
      userName: config.userInfo.userName || '',
      userType: config.userInfo.userType,
    })
    // this.loadHomePage();
  },

  loadHomePage() {
    wx.stopPullDownRefresh();

    // this.setData({
    //   pageLoading: true,
    // });
    // fetchHome({
    //   studentId: config.userInfo.studentId
    // }).then(res => {
    //   const {
    //     SYLB,
    //     Notice,
    //     Material
    //   } = res.data
    //   this.setData({
    //     pageLoading: false,
    //     SYLB,
    //     Notice,
    //     Material,
    //     imgSrcs: SYLB.map(o => o.imageOssUrl)
    //   })
    // })
  },

  onReTry() {},
  goDetail(e) {
    if (!config.userId) {
      wx.navigateTo({
        url: '/pages/login/login',
      })
      return
    }
    const {
      item
    } = e.currentTarget.dataset
    wx.removeStorageSync('currentStudent')
    wx.removeStorageSync('currentStep')
    wx.navigateTo({
      url: item.url,
    })
  },
  goVideo(e) {
    const {
      item
    } = e.currentTarget.dataset
    wx.setStorageSync('currentMaterial', JSON.stringify(item))
    wx.navigateTo({
      url: '/pages/video/index',
    })
  }

});