// pages/login/login.js
import {
  config,
  cdnBase
} from '../../config/index';
import Toast from 'tdesign-miniprogram/toast/index';
import {
  fetchLoginByPhone,
  fetchUserInfo
} from '../../services/api/api';
import dayjs from 'dayjs'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cdnBase,
    checked: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  initUser() {
    fetchUserInfo({
      openId: config.openId,
      userId: config.userId
    }).then(res1 => {
      const data = res1
      config.userInfo = data
      if (config.userInfo.userName == null) {
        config.userInfo.userName = config.userInfo.nickName
      }
      if (config.userInfo.age > 0) {
        config.userInfo.ageStr = dayjs().diff(dayjs(config.userInfo.age * 1000), 'years')
      }
      wx.switchTab({
        url: `/pages/home/home`,
      });

    })
  },
  login() {
    if (!this.data.checked) {
      Toast({
        context: this,
        selector: '#t-toast',
        message: '请阅读并同意《服务条款》与《用户平台使用协议》',
      });
      return
    }
  },
  checkChange(e) {
    this.setData({
      checked: e.detail.checked
    })
  },
  getPhoneNumber(e) {
    if (!this.data.checked) {
      Toast({
        context: this,
        selector: '#t-toast',
        message: '请阅读并同意《服务条款》与《用户平台使用协议》',
      });
      return
    }
    fetchLoginByPhone({
      code: e.detail.code,
      openId: config.openId,
      unionId: config.unionId
    }).then(res => {
      if (res.data.userId) {
        wx.setStorage({
          key: "isLogout",
          data: "0"
        })
        config.userId = res.data.userId
        this.initUser()
      }
    })
  }

})