import {
  config,
  cdnBase
} from '../../config/index';


function calculatePointOnCircle(centerX, centerY, radius, angleInDegrees) {
  var angleInRadians = (angleInDegrees - 270) * Math.PI / 180.0;
  var x = centerX + (radius * Math.cos(angleInRadians));
  var y = centerY + (radius * Math.sin(angleInRadians));
  return {
    x,
    y
  };
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cdnBase,
    isRun: false,
    isCheck: false,
    step: 0,
    measureFirst: 0,
    measureSecond: 0,
    measureThird: 0,
    dialogVisible: false,
    msg: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    this.init()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    this.end()
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  onResize(res) {
    console.log("resize:", res)
  },
  init() {
    setTimeout(() => {
      wx.getStorage({
        key: 'currentStudent',
        success: (res) => {
          const currentStudent = JSON.parse(res.data)
          this.setData({
            currentStudent
          })
        }
      })
      wx.setKeepScreenOn({
        keepScreenOn: true
      })
      const {
        screenWidth,
        screenHeight
      } = wx.getWindowInfo()

      this.setData({
        _cx: screenWidth / 2,
        _cy: -screenHeight / 1.4,
        _r: screenHeight * 1.5,
        _br: 10,
        _angleStart: -30,
        _angleEnd: 30,
        _diff: 0
      })

      // 通过 SelectorQuery 获取 Canvas 节点
      wx.createSelectorQuery()
        .select('#canvas')
        .fields({
          node: true,
          size: true,
        })
        .exec(this.initCanvas.bind(this))

      wx.createSelectorQuery()
        .select('#canvas1')
        .fields({
          node: true,
          size: true,
        })
        .exec(this.initCanvas1.bind(this))
    }, 600)

  },
  initCanvas(res) {
    const width = res[0].width
    const height = res[0].height

    const canvas = res[0].node

    const ctx = canvas.getContext('2d')

    const dpr = wx.getSystemInfoSync().pixelRatio
    canvas.width = width * dpr
    canvas.height = height * dpr
    ctx.scale(dpr, dpr)

    this.render(canvas, ctx)
  },

  render(canvas, ctx) {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    this.draw(ctx)
  },

  draw(ctx) {
    function line(from, to, angle, text, color = '#ffffff') {
      ctx.beginPath()
      ctx.moveTo(from.x, from.y)
      ctx.lineTo(to.x, to.y)
      ctx.strokeStyle = color
      ctx.stroke()
      if (text != null) {
        const metrics = ctx.measureText(text)
        ctx.font = "16px Arial";
        ctx.strokeText(text, to.x - metrics.width / 2, to.y + 18)
      }
    }

    const {
      _cx,
      _cy,
      _r,
      _angleStart,
      _angleEnd
    } = this.data

    const colors = ['#b02923', '#cea129', '#176160']
    ctx.beginPath()
    ctx.lineWidth = 20;
    ctx.lineCap = "round";
    ctx.strokeStyle = '#9FB6C7';
    ctx.arc(_cx, _cy - 6, _r - 5, Math.PI / 180 * (90 - _angleEnd - 2), Math.PI / 180 * (90 - _angleStart + 2), false)
    ctx.stroke()
    ctx.beginPath()
    ctx.lineWidth = 10
    ctx.lineCap = "butt";
    ctx.strokeStyle = colors[0];
    ctx.arc(_cx, _cy, _r + 5, Math.PI / 180 * (90 - _angleEnd - 2), Math.PI / 180 * (90 - 7), false)
    ctx.stroke()
    ctx.beginPath()
    ctx.strokeStyle = colors[1];
    ctx.arc(_cx, _cy, _r + 5, Math.PI / 180 * (90 - 7), Math.PI / 180 * (90 - 5), false)
    ctx.stroke()
    ctx.beginPath()
    ctx.strokeStyle = colors[2];
    ctx.arc(_cx, _cy, _r + 5, Math.PI / 180 * (90 - 5), Math.PI / 180 * (90 + 5), false)
    ctx.stroke()
    ctx.beginPath()
    ctx.strokeStyle = colors[1];
    ctx.arc(_cx, _cy, _r + 5, Math.PI / 180 * (90 + 5), Math.PI / 180 * (90 + 7), false)
    ctx.stroke()
    ctx.beginPath()
    ctx.strokeStyle = colors[0];
    ctx.arc(_cx, _cy, _r + 5, Math.PI / 180 * (90 + 7), Math.PI / 180 * (90 - _angleStart + 2), false)
    ctx.stroke()

    ctx.beginPath()
    ctx.lineWidth = 1
    for (let i = _angleStart; i <= _angleEnd; i++) {
      let from = calculatePointOnCircle(_cx, _cy, _r, i)
      let to = calculatePointOnCircle(_cx, _cy, _r + (i % 5 == 0 ? 20 : 10), i)
      line(from, to, i, i % 5 == 0 ? Math.abs(i) + '°' : null)
      if (i % 5 == 0) {
        let from1 = calculatePointOnCircle(_cx, _cy, _r - 20, i)
        let to1 = calculatePointOnCircle(_cx, _cy, _r, i)
        line(from1, to1, i, null, '#8599AE')
      }
    }


  },

  initCanvas1(res) {
    const width = res[0].width
    const height = res[0].height

    const canvas = res[0].node
    const ctx = canvas.getContext('2d')

    const dpr = wx.getSystemInfoSync().pixelRatio
    canvas.width = width * dpr
    canvas.height = height * dpr
    ctx.scale(dpr, dpr)

    const renderLoop = () => {
      this.render1(canvas, ctx)
      canvas.requestAnimationFrame(renderLoop)
    }
    canvas.requestAnimationFrame(renderLoop)
  },
  render1(canvas, ctx) {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    this.draw1(ctx)
  },

  draw1(ctx) {
    const {
      _cx,
      _cy,
      _r,
      _br,
      _beta = 0,
    } = this.data

    const {
      x,
      y
    } = calculatePointOnCircle(_cx, _cy, _r - _br, _beta)
    ctx.beginPath();
    ctx.arc(x, y, _br, 0, 2 * Math.PI)
    const grd = ctx.createRadialGradient(x, y, 2, x, y, _br);
    grd.addColorStop(0, "#bdbcbc");
    grd.addColorStop(1, "#757474");
    ctx.fillStyle = grd;
    ctx.fill();

    ctx.strokeStyle = '#ffffff'
    ctx.beginPath();
    const text = `角度：${Math.abs(_beta).toFixed(1)}°`
    const metrics = ctx.measureText(text)
    ctx.font = "40px 微软雅黑";
    ctx.strokeText(text, _cx - metrics.width / 2, _cy + _r - 50)
  },
  onBack() {
    wx.navigateBack();
  },
  measure() {
    wx.startDeviceMotionListening({
      interval: "game"
    })
    const {
      platform
    } = wx.getDeviceInfo()

    wx.onDeviceMotionChange(res => {
      const {
        _diff,
        _angleStart,
        _angleEnd,
        _max
      } = this.data
      const beta = platform == 'ios' ? -res.beta : res.beta
      const _beta = beta < 0 ? Math.max(beta - _diff, _angleStart) : Math.min(beta - _diff, _angleEnd)
      this.setData({
        _beta,
        _max: Math.max(Math.abs(_beta), _max)
      })
    })
  },
  start() {
    const {
      isRun
    } = this.data
    if (isRun) {
      this.end()
      return
    }
    this.setData({
      isRun: true,
      _max: 0,
      _beta: 0
    })
    this.measure()
  },
  end() {
    wx.stopDeviceMotionListening()
    const {
      step,
      currentStudent,
      _max
    } = this.data
    this.setData({
      isRun: false,
      step: step + 1
    })
    if (step == 0) {
      const measureFirst = Number(_max).toFixed(1)
      this.setData({
        measureFirst
      })
      this.showDialog('胸段测量完成，请继续测量胸腰段', 2000)
    } else if (step == 1) {
      const measureSecond = Number(_max).toFixed(1)
      this.setData({
        measureSecond
      })
      this.showDialog('胸腰段测量完成，请继续测量腰段', 2000)
    } else if (step == 2) {
      const measureThird = Number(_max).toFixed(1)
      const {
        measureFirst,
        measureSecond
      } = this.data
      this.setData({
        measureThird
      })
      currentStudent.measureFirst = measureFirst;
      currentStudent.measureSecond = measureSecond;
      currentStudent.measureThird = measureThird;
      wx.setStorage({
        key: "currentStudent",
        data: JSON.stringify(currentStudent)
      })
      this.showDialog('测量完成，您可以重新测量或者返回继续测量下一位', 2000)
      // setTimeout(() => {
      //   this.onBack()
      // }, 1000)
    }
  },
  check() {
    const {
      isCheck,
      _beta
    } = this.data
    if (isCheck) {
      this.setData({
        isCheck: false,
        _diff: _beta,
        _beta: 0
      })
      wx.stopDeviceMotionListening()
      return
    }
    this.setData({
      isCheck: true,
      isRun: false,
      _diff: 0,
      _beta: 0
    })
    this.measure()
  },
  reStart() {
    this.setData({
      step: 0,
      measureFirst: 0,
      measureSecond: 0,
      measureThird: 0
    })
  },
  showDialog(msg, time) {
    this.setData({
      msg,
      dialogVisible: true
    });
    if (time) {
      setTimeout(() => {
        this.setData({
          dialogVisible: false
        })
      }, time)
    }
  },

  closeDialog() {
    this.setData({
      dialogVisible: false
    });
  },
})