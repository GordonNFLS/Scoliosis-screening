import {
  config,
  cdnBase
} from '../../config/index';

import dayjs from 'dayjs';

const getDefaultData = () => ({
  cdnBase,
  showMakePhone: false,
  userInfo: {
    avatar: '',
    userName: '正在登录...',
    phonenumber: '',
  },
  customerServiceInfo: {},
  currAuthStep: 1,
  showKefu: true,
  versionNo: '',
  cards: [{
      "title": "我的学生",
      "img": "形状 554.png",
      "path": "/pages/my/student/index",
      "userType": '01'
    },
    {
      "title": "我的孩子",
      "img": "形状 554.png",
      "path": "/pages/my/student/index",
      "userType": '02'
    },
    {
      "title": "健康食谱",
      "img": "形状 1292.png",
      "path": "/pages/my/food/index"
    },
    {
      "title": "健康运动",
      "img": "形状 1293.png",
      "path": "/pages/my/sport/index"
    },
    {
      "title": "脊柱测弯",
      "img": "形状 12.png",
      "path": "/pages/my/spine/index"
    }
  ]
});

Page({
  data: getDefaultData(),

  onLoad() {},

  onShow() {
    this.getTabBar().init();
    this.init();
  },
  onPullDownRefresh() {
    this.init();
  },

  init() {
    this.fetUseriInfoHandle();
    this.fetchData()
  },

  fetUseriInfoHandle() {
    this.setData({
      userInfo: config.userInfo,
      currAuthStep: 2
    })

  },

  fetchData() {},


  openMakePhone() {
    this.setData({
      showMakePhone: true
    });
  },

  closeMakePhone() {
    this.setData({
      showMakePhone: false
    });
  },

  gotoUserEditPage() {
    const {
      currAuthStep
    } = this.data;
    if (currAuthStep === 2) {
      wx.navigateTo({
        url: '/pages/usercenter/person-info/index'
      });
    } else {
      this.fetUseriInfoHandle();
    }
  },
  goCalendarDetail(e) {
    wx.navigateTo({
      url: '/pages/plans/month/index',
    })
  },
  goMyDetail(e) {
    const {
      path
    } = e.currentTarget.dataset.item;
    wx.navigateTo({
      url: path,
    })
  },
  goPlanDetail(e) {
    const {
      item
    } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/plans/detail/index?planDate=${item.planDate}`,
    })
  },
  goCycleDetail(e) {
    wx.navigateTo({
      url: `/pages/plans/cycle/index`,
    })
  }
});