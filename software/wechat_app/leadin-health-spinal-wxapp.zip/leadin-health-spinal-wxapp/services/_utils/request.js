import {
  config,
  cdnBase
} from '../../config/index';
import Toast from 'tdesign-miniprogram/toast/index';
const http = ({
  url,
  method,
  data,
  success,
  fail,
  header = {
    "Content-Language": "zh_CN"
  }
}) => {
  const isToken = (header || {}).isToken === false;
  if (config.token && !isToken) {
    header["Authorization"] = "Bearer " + config.token; // 让每个请求携带自定义token 请根据实际情况自行修改
  }
  wx.showLoading({
    title: '加载中...',
    mask: true
  })
  return wx.request({
    url: cdnBase + config.baseApi + url, //仅为示例，并非真实的接口地址
    method,
    data,
    header,
    success: (res) => {
      const data = res.data
      success(data)
      if (data.code && data.code != 200) {
        if (data.code == 401) {
          wx.navigateTo({
            url: `/pages/login1/login`,
          });
        } else {
          Toast({
            context: this,
            selector: '#t-toast',
            message: data.msg,
          });
        }

      }
    },
    fail,
    complete: (e) => {
      wx.hideLoading()
    }
  })
}

const get = ({
  url,
  data
}) => {

  return new Promise((resolve, reject) => {
    http({
      url,
      method: 'GET',
      data,
      success: resolve,
      fail: reject
    })
  });
}
const post = ({
  url,
  data,
}) => {
  return new Promise((resolve, reject) => {
    http({
      url,
      method: 'POST',
      data,
      success: resolve,
      fail: reject
    })
  });
}
const uploadRequest = ({
  url,
  data,
}) => {
  return new Promise((resolve, reject) => {
    const header = {}
    if (config.token) {
      header["Authorization"] = "Bearer " + config.token; // 让每个请求携带自定义token 请根据实际情况自行修改
    }
    wx.showLoading({
      title: '上传中...',
      mask: true
    })
    wx.uploadFile({
      url: cdnBase + config.baseApi + url,
      header,
      filePath: data,
      header: {
        "Content-Type": "multipart/form-data",
      },
      name: 'file',
      success(res) {
        resolve(JSON.parse(res.data))
      },
      fail(e) {
        reject(e)
      },
      complete: (e) => {
        wx.hideLoading()
      }
    })
  });
}
const http1 = ({
  url,
  method,
  data,
  success,
  fail,
  header = {
    "Content-Language": "zh_CN"
  }
}) => {
  const isToken = (header || {}).isToken === false;
  if (config.token && !isToken) {
    header["Authorization"] = "Bearer " + config.token; // 让每个请求携带自定义token 请根据实际情况自行修改
  }
  wx.showLoading({
    title: '加载中...',
    mask: true
  })
  return wx.request({
    url: cdnBase + url, //仅为示例，并非真实的接口地址
    method,
    data,
    header,
    success: (res) => {
      const data = res.data
      success(data)
      if (data.code != 200) {
        if (data.code == 401) {
          wx.navigateTo({
            url: `/pages/login1/login`,
          });
        } else {
          Toast({
            context: this,
            selector: '#t-toast',
            message: data.msg,
          });
        }

      }
    },
    fail,
    complete: (e) => {
      wx.hideLoading()
    }
  })
}
const get1 = ({
  url,
  data
}) => {

  return new Promise((resolve, reject) => {
    http1({
      url,
      method: 'GET',
      data,
      success: resolve,
      fail: reject
    })
  });
}
module.exports = {
  get,
  post,
  uploadRequest,
  get1
}