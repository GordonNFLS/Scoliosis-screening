import {
  get,
  post,
  uploadRequest,
  get1
} from '../_utils/request'

export function fetchSysConfigCarousel() {
  return get({
    url: `/system/SysConfigCarousel/list`,
    data: {
      pageNum: 1,
      pageSize: 100
    }
  })
}
export function fetchCaptchaImage() {
  return get({
    url: `/captchaImage`,
    data: {}
  })
}
export function fetchLogin(data) {
  return post({
    url: `/login`,
    data
  })
}
export function fetchLoginByJsCode(data) {
  return post({
    url: `/user/loginByJsCode`,
    data
  })
}
export function fetchLoginByPhone(data) {
  return post({
    url: `/user/loginByPhone`,
    data
  })
}

export function fetchSysConfigMaterial() {
  return get({
    url: `/system/SysConfigMaterial/list`,
    data: {
      pageNum: 1,
      pageSize: 100
    }
  })
}

export function fetchSysConfigNotice() {
  return get({
    url: `/system/SysConfigNotice/list`,
    data: {
      pageNum: 1,
      pageSize: 100
    }
  })
}
export function fetchSysConfigMaterial2() {
  return get({
    url: `/system/SysConfigMaterial2/list`,
    data: {}
  })
}
export function fetchUserInfo(data) {
  return post({
    url: `/user/queryUserByOpenId`,
    data
  })
}
export function fetchHome(data) {
  return post({
    url: `/student/home`,
    data
  })
}
export function fetchStudentLogin(data) {
  return post({
    url: `/student/login`,
    data
  })
}
export function fetchStudentLogout(data) {
  return post({
    url: `/student/logout`,
    data
  })
}
export function fetchStudentUpload(data) {
  return uploadRequest({
    url: `/student/upload`,
    data
  })
}
export function fetchStudentAvatar(data) {
  return post({
    url: `/student/avatar`,
    data
  })
}
export function fetchAllStudent(data) {
  return post({
    url: `/student/my/allStudent`,
    data
  })
}

export function fetchYdcf(data) {
  return post({
    url: `/student/home/getYdcfOnParentId`,
    data
  })
}
export function fetchPlansOfTheWeek(data) {
  return post({
    url: `/student/my/plansOfTheWeek`,
    data
  })
}

export function fetchPlansOfTheMonth(data) {
  return post({
    url: `/student/my/plansOfTheMonth`,
    data
  })
}
export function fetchPlansOfTheDate(data) {
  return post({
    url: `/student/my/plansOfTheDate`,
    data
  })
}

export function fetchQrCodeLogin(data) {
  return post({
    url: `/student/qrCode/login`,
    data
  })
}
export function fetchAllExams(data) {
  return post({
    url: `/student/my/allExams`,
    data
  })
}
export function fetchAllPrescriptionNames(data) {
  return post({
    url: `/student/my/allPrescriptionNames`,
    data
  })
}
export function fetchExamDetail(data) {
  return post({
    url: `/student/my/examDetail`,
    data
  })
}
export function fetchPrescriptionReportDetail(data) {
  return post({
    url: `/student/my/prescriptionReportDetail`,
    data
  })
}

export function wxLogin(data) {
  return new Promise((resolve, reject) => {
    wx.login({
      success: res => {
        resolve(res)
      },
      fail: (errMsg, errno) => {
        reject(errMsg, errno)
      }
    })
  });
}

export function fetchH5First(data) {
  return get1({
    url: `/spine/H5First.html`,
    data
  })
}

export function fetchH5Second(data) {
  return get1({
    url: `/spine/H5Second.html`,
    data
  })
}
export function fetchPlansOfTheMz(data) {
  return post({
    url: `/student/my/plansOfTheMz`,
    data
  })
}
export function fetchMzFeedbackList(data) {
  return post({
    url: `/getMzFeedbackList`,
    data
  })
}
export function fetchMzFeedback(data) {
  return post({
    url: `/getMzFeedback`,
    data
  })
}
export function fetchInsertMzFeedback(data) {
  return post({
    url: `/student/insertMzFeedback`,
    data
  })
}

export function fetchMonitionChart(data) {
  return post({
    url: `/machine/monition/chart`,
    data
  })
}

export function fetchManagerEdit(data) {
  return post({
    url: `/user/manager/edit`,
    data
  })
}

export function fetchUpload(data) {
  return uploadRequest({
    url: `/material/file/upload`,
    data
  })
}
export function fetchSpineDevBind(data) {
  return post({
    url: `/spine/dev/bind`,
    data
  })
}
export function fetchSpineDevUnBind(data) {
  return post({
    url: `/spine/dev/unbind`,
    data
  })
}
export function fetchSpineMeasureAdd(data) {
  return post({
    url: `/spine/measure/add`,
    data
  })
}
export function fetchSpineMeasureStudentQuery(data) {
  return post({
    url: `/spine/measure/student/query`,
    data
  })
}

export function fetchSpineMeasureUserQuery(data) {
  return post({
    url: `/spine/measure/user/query`,
    data
  })
}
export function fetchSpineStudentList(data) {
  return post({
    url: `/spine/student/list`,
    data
  })
}
export function fetchSpineStudentListMeasure(data) {
  return post({
    url: `/spine/student/list/measure`,
    data
  })
}
export function fetchMaterial(data) {
  return post({
    url: `/material/info/listByType`,
    data
  })
}
export function fetchMeasureChild(data) {
  return post({
    url: `/spine/measure/child/query`,
    data
  })
}

export function fetchStudentAdd(data) {
  return post({
    url: `/spine/student/add`,
    data
  })
}
export function fetchStudentUpdate(data) {
  return post({
    url: `/spine/student/update`,
    data
  })
}
export function fetchStudentDelete(data) {
  return post({
    url: `/spine/student/delete`,
    data
  })
}